Welcome to JsutherX!
Please place scripts in the .\\Scripts folder as a .LUA or .TXT.

Thanks,
-- Jsuther X Team